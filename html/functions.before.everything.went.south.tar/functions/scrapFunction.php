<?php

function getTodayScrapTotals($conn) {

    $sql = "
        SELECT 
            SUM(scrap_lbs) AS total_lbs,
            SUM(scrap_quantity) AS total_qty,
            SUM(scrap_ext) AS total_ext
        FROM pwo_scraps
        WHERE DATE(created_date_time) = CURDATE();
    ";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        return "<tr><td colspan='4'>Query Error: " . mysqli_error($conn) . "</td></tr>";
    }

    $row = mysqli_fetch_assoc($result);

    // Format today’s date
    $today = date("Y-m-d");

    // Ensure null values show as 0
    $total_lbs = $row['total_lbs'] ?? 0;
    $total_qty = $row['total_qty'] ?? 0;
    $total_ext = $row['total_ext'] ?? 0;

    // Add comma formatting
    $total_lbs = number_format($total_lbs);
    $total_qty = number_format($total_qty);
    $total_ext = number_format($total_ext, 2);  // keep cents

    // Return a single table row
    return "
        <tr>
            <td width=25%>{$total_lbs} lbs.</td>
            <td width=25%>{$total_qty} ft.</td>
            <td width=25%>\${$total_ext}</td>
            <td width=25%>{$today}</td>
        </tr>
    ";
}


function getMonthToDateScrapTotals($conn) {

    $sql = "
        SELECT
            SUM(scrap_lbs) AS total_lbs,
            SUM(scrap_quantity) AS total_qty,
            SUM(scrap_ext) AS total_ext
        FROM pwo_scraps
        WHERE created_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
          AND created_date_time <  DATE_ADD(LAST_DAY(CURDATE()), INTERVAL 1 DAY);
    ";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        return "<tr><td colspan='4'>Query Error: " . mysqli_error($conn) . "</td></tr>";
    }

    $row = mysqli_fetch_assoc($result);

    // Ensure null values show as 0
    $total_lbs = $row['total_lbs'] ?? 0;
    $total_qty = $row['total_qty'] ?? 0;
    $total_ext = $row['total_ext'] ?? 0;

    // Add comma formatting
    $total_lbs = number_format($total_lbs);
    $total_qty = number_format($total_qty);
    $total_ext = number_format($total_ext, 2);  // keep cents

    // Label for the date column
    $label = date("F Y");

    // Return a single table row
    return "
        <tr>
            <td width=25%>{$total_lbs} lbs.</td>
            <td width=25%>{$total_qty} ft.</td>
            <td width=25%>\${$total_ext}</td>
            <td width=25%>{$label}</td>
        </tr>
    ";
}

function getQuartlyToDateScrapTotals($conn) {

    $sql = "
	SELECT
    		SUM(scrap_lbs) AS total_lbs,
    		SUM(scrap_quantity) AS total_qty,
    		SUM(scrap_ext) AS total_ext
	FROM pwo_scraps
	WHERE created_date_time >= MAKEDATE(YEAR(CURDATE()), 1)
      		+ INTERVAL QUARTER(CURDATE())*3 - 3 MONTH
  	AND created_date_time <  MAKEDATE(YEAR(CURDATE()), 1)
      		+ INTERVAL QUARTER(CURDATE())*3 MONTH;
	";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        return "<tr><td colspan='4'>Query Error: " . mysqli_error($conn) . "</td></tr>";
    }

    $row = mysqli_fetch_assoc($result);

    // Ensure null values show as 0
    $total_lbs = $row['total_lbs'] ?? 0;
    $total_qty = $row['total_qty'] ?? 0;
    $total_ext = $row['total_ext'] ?? 0;

    // Add comma formatting
    $total_lbs = number_format($total_lbs);
    $total_qty = number_format($total_qty);
    $total_ext = number_format($total_ext, 2);  // keep cents

    // Label for the date column
    $quarter = ceil(date("n") / 3);   // n = month number
    $label = "Q" . $quarter;


    // Return a single table row
    return "
        <tr>
            <td width=25%>{$total_lbs} lbs.</td>
            <td width=25%>{$total_qty} ft.</td>
            <td width=25%>\${$total_ext}</td>
            <td width=25%>{$label}</td>
        </tr>
    ";
}

function getYearToDateScrapTotals($conn) {

    $sql = "
        SELECT
            SUM(scrap_lbs) AS total_lbs,
            SUM(scrap_quantity) AS total_qty,
            SUM(scrap_ext) AS total_ext
        FROM pwo_scraps
        WHERE created_date_time >= MAKEDATE(YEAR(CURDATE()), 1)
          AND created_date_time <  CURDATE() + INTERVAL 1 DAY;
    ";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        return "<tr><td colspan='4'>Query Error: " . mysqli_error($conn) . "</td></tr>";
    }

    $row = mysqli_fetch_assoc($result);

    // Ensure null values show as 0
    $total_lbs = $row['total_lbs'] ?? 0;
    $total_qty = $row['total_qty'] ?? 0;
    $total_ext = $row['total_ext'] ?? 0;

    // Add comma formatting
    $total_lbs = number_format($total_lbs);
    $total_qty = number_format($total_qty);
    $total_ext = number_format($total_ext, 2);

    // Label for the date column (example: "YTD 2025")
    $label = "YTD " . date("Y");

    // Return a single table row
    return "
        <tr>
            <td width=25%>{$total_lbs} lbs.</td>
            <td width=25%>{$total_qty} ft.</td>
            <td width=25%>\${$total_ext}</td>
            <td width=25%>{$label}</td>
        </tr>
    ";
}

function getMonthlyScrapTotals($conn) {
    $sql = "
        SELECT 
            MONTH(created_date_time) AS month_num,
            SUM(scrap_lbs) AS total_lbs,
            SUM(scrap_quantity) AS total_qty,
            SUM(scrap_ext) AS total_ext
        FROM pwo_scraps
        WHERE YEAR(created_date_time) = YEAR(CURDATE())
        GROUP BY MONTH(created_date_time)
        ORDER BY MONTH(created_date_time);
    ";

    $result = mysqli_query($conn, $sql);

    // Prepare arrays for all 12 months (initialize to 0)
    $months = array_fill(1, 12, 0);
    $lbs = array_fill(1, 12, 0);
    $qty = array_fill(1, 12, 0);
    $ext = array_fill(1, 12, 0);

    while ($row = mysqli_fetch_assoc($result)) {
        $m = (int)$row['month_num'];
        $lbs[$m] = (float)$row['total_lbs'];
        $qty[$m] = (float)$row['total_qty'];
        $ext[$m] = (float)$row['total_ext'];
    }

    return [
        "months" => $months, // 1–12
        "lbs"    => $lbs,
        "qty"    => $qty,
        "ext"    => $ext
    ];
}


function getScrapTables24Hours() {

    $conn = connectRubiconTci();

    /*
     * Determine the beginning of the current shift.
     *
     * Shift schedule:
     *
     * 1st Shift: 08:00 - 16:00
     * 2nd Shift: 16:00 - 00:00
     * 3rd Shift: 00:00 - 08:00
     *
     * The three completed shifts immediately preceding
     * the current shift represent the previous 24 hours.
     */

    $currentHour = (int)date('H');

    if ($currentHour < 8) {

        // Currently in 3rd Shift
        $currentShiftStart = date('Y-m-d') . ' 00:00:00';

    } elseif ($currentHour < 16) {

        // Currently in 1st Shift
        $currentShiftStart = date('Y-m-d') . ' 08:00:00';

    } else {

        // Currently in 2nd Shift
        $currentShiftStart = date('Y-m-d') . ' 16:00:00';
    }


    /*
     * Build the three completed shifts.
     */

    $shiftEnd = new DateTime($currentShiftStart);

    $shifts = [];

    for ($i = 1; $i <= 3; $i++) {

        $shiftStart = clone $shiftEnd;

        $shiftStart->modify('-8 hours');

        $shifts[] = [
            'start' => $shiftStart->format('Y-m-d H:i:s'),
            'end'   => $shiftEnd->format('Y-m-d H:i:s')
        ];

        $shiftEnd = clone $shiftStart;
    }


    /*
     * Display oldest shift first.
     */

    $shifts = array_reverse($shifts);


    /*
     * 24-HOUR GRAND TOTALS
     */

    $grandTotalScrapLbs      = 0;
    $grandTotalScrapQuantity = 0;
    $grandTotalScrapCost     = 0;
    $grandTotalRecords       = 0;


    /*
     * SQL query.
     */

    $sql = "
        SELECT
            pwo_number,
            created_date_time,
            scrap_lbs_ext,
            scrap_quantity,
            scrap_ext,
            scrap_reason,
            created_by_user,
            verified_by
        FROM v_pwo_scraps
        WHERE scrap_lbs_ext != 0.00
          AND created_date_time >= ?
          AND created_date_time < ?
        ORDER BY created_date_time DESC
    ";


    $html = '';


    /*
     * ==========================================================
     * 24-HOUR SUMMARY
     * ==========================================================
     *
     * We'll calculate the grand totals after processing
     * the three shifts, so the summary will be inserted
     * after all totals are known.
     *
     * We temporarily store the shift HTML here.
     */

    $shiftHtml = '';


    foreach ($shifts as $shift) {

        $startDateTime = $shift['start'];
        $endDateTime   = $shift['end'];


        /*
         * Determine shift name.
         */

        $startHour = (int)date(
            'H',
            strtotime($startDateTime)
        );

        if ($startHour === 0) {

            $shiftName = '3rd Shift';

        } elseif ($startHour === 8) {

            $shiftName = '1st Shift';

        } else {

            $shiftName = '2nd Shift';
        }


        /*
         * Determine the shift date.
         */

        $shiftDate = date(
            'F j, Y',
            strtotime($startDateTime)
        );


        /*
         * Prepare SQL statement.
         */

        $stmt = $conn->prepare($sql);

        if (!$stmt) {

            $shiftHtml .= "
                <div class='database-error'>
                    SQL Prepare Error:
                    " . htmlspecialchars($conn->error) . "
                </div>
            ";

            continue;
        }


        /*
         * Bind shift start/end times.
         */

        $stmt->bind_param(
            'ss',
            $startDateTime,
            $endDateTime
        );


        /*
         * Execute query.
         */

        $stmt->execute();

        $result = $stmt->get_result();


        /*
         * Shift totals.
         */

        $totalScrapLbs      = 0;
        $totalScrapQuantity = 0;
        $totalScrapCost     = 0;
        $recordCount        = 0;


        /*
         * Store rows so we can calculate totals before
         * displaying the table.
         */

        $rows = [];

        while ($row = $result->fetch_assoc()) {

            $rows[] = $row;


            /*
             * Shift totals.
             */

            $totalScrapLbs +=
                (float)($row['scrap_lbs_ext'] ?? 0);

            $totalScrapQuantity +=
                (float)($row['scrap_quantity'] ?? 0);

            $totalScrapCost +=
                (float)($row['scrap_ext'] ?? 0);

            $recordCount++;


            /*
             * Grand 24-hour totals.
             */

            $grandTotalScrapLbs +=
                (float)($row['scrap_lbs_ext'] ?? 0);

            $grandTotalScrapQuantity +=
                (float)($row['scrap_quantity'] ?? 0);

            $grandTotalScrapCost +=
                (float)($row['scrap_ext'] ?? 0);

            $grandTotalRecords++;
        }


        /*
         * ======================================================
         * SHIFT TABLE
         * ======================================================
         */

        $shiftHtml .= "

            <div class='scrap-shift-section'>

                <h2 class='scrap-table-title'>
                    $shiftName - $shiftDate
                </h2>

                <div class='shift-time'>
                    " .
                    date(
                        'm/d/Y g:i A',
                        strtotime($startDateTime)
                    ) .
                    "
                    -
                    " .
                    date(
                        'm/d/Y g:i A',
                        strtotime($endDateTime)
                    ) .
                    "
                </div>


                <!-- SHIFT SUMMARY -->

                <div class='scrap-summary'>

                    <div class='summary-item'>

                        <span class='summary-label'>
                            Total Scrap
                        </span>

                        <span class='summary-value'>
                            " .
                            number_format(
                                $totalScrapLbs,
                                2
                            ) .
                            " lbs
                        </span>

                    </div>


                    <div class='summary-item'>

                        <span class='summary-label'>
                            Scrap Quantity
                        </span>

                        <span class='summary-value'>
                            " .
                            number_format(
                                $totalScrapQuantity,
                                2
                            ) .
                            "
                        </span>

                    </div>


                    <div class='summary-item'>

                        <span class='summary-label'>
                            Total Cost
                        </span>

                        <span class='summary-value'>
                            $" .
                            number_format(
                                $totalScrapCost,
                                2
                            ) .
                            "
                        </span>

                    </div>


                    <div class='summary-item'>

                        <span class='summary-label'>
                            Records
                        </span>

                        <span class='summary-value'>
                            $recordCount
                        </span>

                    </div>

                </div>


                <!-- SCRAP TABLE -->

                <table class='scrap-table'>

                    <thead>

                        <tr>
                            <th>PWO Number</th>
                            <th>Created Date/Time</th>
                            <th>Scrap Lbs</th>
                            <th>Scrap Quantity</th>
                            <th>Scrap Cost</th>
                            <th>Scrap Reason</th>
                            <th>Created By</th>
                            <th>Verified By</th>
                        </tr>

                    </thead>

                    <tbody>
        ";


        /*
         * Display records.
         */

        if ($recordCount === 0) {

            $shiftHtml .= "

                <tr>

                    <td colspan='8' class='no-data'>
                        No scrap records found for this shift.
                    </td>

                </tr>

            ";

        } else {

            foreach ($rows as $row) {

                /*
                 * PWO Number
                 */

                $pwoNumber = htmlspecialchars(
                    $row['pwo_number'] ?? ''
                );


                /*
                 * Date / Time
                 */

                $createdDateTime = '';

                if (!empty($row['created_date_time'])) {

                    $createdDateTime = date(
                        'm/d/Y g:i A',
                        strtotime(
                            $row['created_date_time']
                        )
                    );
                }


                /*
                 * Scrap pounds
                 */

                $scrapLbs = number_format(
                    (float)(
                        $row['scrap_lbs_ext'] ?? 0
                    ),
                    2
                );


                /*
                 * Scrap quantity
                 */

                $scrapQuantity = number_format(
                    (float)(
                        $row['scrap_quantity'] ?? 0
                    ),
                    2
                );


                /*
                 * Scrap cost
                 */

                $scrapCost = '$' . number_format(
                    (float)(
                        $row['scrap_ext'] ?? 0
                    ),
                    2
                );


                /*
                 * Scrap reason
                 */

                $scrapReason = htmlspecialchars(
                    $row['scrap_reason'] ?? ''
                );


                /*
                 * Created by
                 */

                $createdBy = htmlspecialchars(
                    $row['created_by_user'] ?? ''
                );


                /*
                 * Verified by
                 */

                $verifiedBy = htmlspecialchars(
                    $row['verified_by'] ?? ''
                );


                /*
                 * Add row.
                 */

                $shiftHtml .= "

                    <tr>

                        <td>$pwoNumber</td>

                        <td>$createdDateTime</td>

                        <td>$scrapLbs</td>

                        <td>$scrapQuantity</td>

                        <td>$scrapCost</td>

                        <td>$scrapReason</td>

                        <td>$createdBy</td>

                        <td>$verifiedBy</td>

                    </tr>

                ";
            }
        }


        /*
         * Close table.
         */

        $shiftHtml .= "

                    </tbody>

                </table>

            </div>

        ";


        $result->free();

        $stmt->close();
    }


    /*
     * ==========================================================
     * 24-HOUR GRAND TOTAL
     * ==========================================================
     */

    $html .= "

        <div class='scrap-24hour-summary'>

            <h2 class='scrap-24hour-title'>
                Last 24 Hours Scrap Summary
            </h2>


            <div class='scrap-24hour-summary-items'>


                <div class='summary-item grand-total'>

                    <span class='summary-label'>
                        Total Scrap
                    </span>

                    <span class='summary-value'>
                        " .
                        number_format(
                            $grandTotalScrapLbs,
                            2
                        ) .
                        " lbs
                    </span>

                </div>


                <div class='summary-item grand-total'>

                    <span class='summary-label'>
                        Scrap Quantity
                    </span>

                    <span class='summary-value'>
                        " .
                        number_format(
                            $grandTotalScrapQuantity,
                            2
                        ) .
                        "
                    </span>

                </div>


                <div class='summary-item grand-total'>

                    <span class='summary-label'>
                        Total Cost
                    </span>

                    <span class='summary-value'>
                        $" .
                        number_format(
                            $grandTotalScrapCost,
                            2
                        ) .
                        "
                    </span>

                </div>


                <div class='summary-item grand-total'>

                    <span class='summary-label'>
                        Total Records
                    </span>

                    <span class='summary-value'>
                        $grandTotalRecords
                    </span>

                </div>


            </div>

        </div>

    ";


    /*
     * Add the three shift tables.
     */

    $html .= $shiftHtml;


    /*
     * Close connection.
     */

    $conn->close();


    return $html;
}


?>
